import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

	public currentLinks = ["https://www.tutorialspoint.com/"];
	public historyLinks = [];
	public headers = new HttpHeaders();
	public options = {};
	public authUser = {
		"uName": '',
		"uPass": ''
	};

	constructor(
			private httpClient: HttpClient
		) { 

		this.headers.append("Access-Control-Allow-Origin", "*");
		this.options = { 'headers': this.headers };
	}

	public currentGetRequest(index){
		return this.httpClient.get(this.currentLinks[index] ,this.options );
	}

}