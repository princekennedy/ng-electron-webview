import { Component, OnInit } from '@angular/core';
import { UrlPagesService } from '../url-pages.service';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import * as $ from "jquery";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(
  		private urlPagesService: UrlPagesService,
    	private dataService: DataService,
		private _router: Router
	) { }

  ngOnInit() {
  	this.dataService.authUser.uName = "Prince Kennedy";
  }

}
